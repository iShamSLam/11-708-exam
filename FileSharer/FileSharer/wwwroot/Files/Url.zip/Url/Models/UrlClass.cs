﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Url.Models
{
    public class UrlClass
    {
        public int Id { get; set; }
        public string Url { get; set; }
        public string ShortUrl { get; set; }
        public DateTime EndDateTime { get; set; }
        public string Password { get; set; }
        public int Count { get; set; }
        public UrlType UrlType { get; set; }
    }

    public enum UrlType
    {
        simple,
        password,
        count,
        data
    }
}
