﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Url.Models;

namespace Url.Controllers
{
    public class DefaultController : Controller
    {
        private MyDbContext db;

        public DefaultController(MyDbContext context)
        {
            db = context;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Url()
        {
            return View();
        }

        public IActionResult R(string i)
        {
            var a = db.UrlClasses.FirstOrDefault(x => x.ShortUrl == i);

            switch (a.UrlType)
            {
                case UrlType.simple:
                    break;

                case UrlType.count:
                    if (a.Count-- < 0)
                        return NotFound();
                    break;

                case UrlType.password:
                    return CheckPasswordForm(i);

                case UrlType.data:
                    if (a.EndDateTime < DateTime.Now)
                        return NotFound();
                    break;
            }

            return Redirect(a.Url);
        }

        public IActionResult SaveUrl(string url)
        {
            string sh = GetUniqueKey(5);
            var b = CheckKey(sh);
            while (b)
            {
                sh = GetUniqueKey(5);
                b = CheckKey(sh);
            }
            UrlClass u = new UrlClass { Url = url, ShortUrl = sh, UrlType = UrlType.simple };
            db.UrlClasses.Add(u);
            db.SaveChanges();

            ViewData["shorturl"] = Request.Scheme + "://" + Request.Host + "/" + u.ShortUrl;

            return View();
        }

        public IActionResult CountUrl()
        {
            return View();
        }

        public IActionResult SaveUrl(string curl, int count)
        {
            string sh = GetUniqueKey(5);
            var b = CheckKey(sh);
            while (b)
            {
                sh = GetUniqueKey(5);
                b = CheckKey(sh);
            }
            UrlClass u = new UrlClass { Url = curl, ShortUrl = sh, UrlType = UrlType.count, Count = count };
            db.UrlClasses.Add(u);
            db.SaveChanges();

            ViewData["shorturl"] = Request.Scheme + "://" + Request.Host + "/" + u.ShortUrl;

            return View();
        }

        public IActionResult PasswordUrl()
        {
            return View();
        }

        public IActionResult SaveUrl(string purl, string password)
        {
            string sh = GetUniqueKey(5);
            var b = CheckKey(sh);
            while (b)
            {
                sh = GetUniqueKey(5);
                b = CheckKey(sh);
            }
            UrlClass u = new UrlClass { Url = purl, ShortUrl = sh, UrlType = UrlType.password, Password = password.GetHashCode().ToString() };
            db.UrlClasses.Add(u);
            db.SaveChanges();

            ViewData["shorturl"] = Request.Scheme + "://" + Request.Host + "/" + u.ShortUrl;

            return View();
        }

        public IActionResult CheckPasswordForm(string key)
        {
            var a = db.UrlClasses.FirstOrDefault(x => x.ShortUrl == key);
            if (a != null && a.UrlType == UrlType.password)
                return View(key);

            return NotFound();
        }

        public IActionResult CheckPassword(string key, string password)
        {
            var a = db.UrlClasses.FirstOrDefault(x => x.ShortUrl == key);

            if (a.Password == password.GetHashCode().ToString())
                return Redirect(a.Url);

            else return Content("Пошел нахуй");
        }

        public IActionResult DateUrl()
        {
            return View();
        }

        public IActionResult SaveUrl(string durl, DateTime date)
        {
            string sh = GetUniqueKey(5);
            var b = CheckKey(sh);
            while (b)
            {
                sh = GetUniqueKey(5);
                b = CheckKey(sh);
            }
            UrlClass u = new UrlClass { Url = durl, ShortUrl = sh, UrlType = UrlType.data, EndDateTime = date};
            db.UrlClasses.Add(u);
            db.SaveChanges();

            ViewData["shorturl"] = Request.Scheme + "://" + Request.Host + "/" + u.ShortUrl;

            return View();
        }

        private  string GetUniqueKey(int size)
        {
            char[] chars =
                "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890".ToCharArray();
            byte[] data = new byte[size];
            using (RNGCryptoServiceProvider crypto = new RNGCryptoServiceProvider())
            {
                crypto.GetBytes(data);
            }
            StringBuilder result = new StringBuilder(size);
            foreach (byte b in data)
            {
                result.Append(chars[b % (chars.Length)]);
            }
            return result.ToString();
        }

        private bool CheckKey (string key)
        {
            var a = db.UrlClasses.FirstOrDefault(x => x.ShortUrl == key);
            if (a.ShortUrl == key)
            {
                switch (a.UrlType)
                {
                    case UrlType.simple:
                        return false;

                    case UrlType.password:
                        return false;

                    case UrlType.count:
                        if (a.Count == 0)
                        {
                            db.UrlClasses.Remove(a);
                            db.SaveChanges();
                            return true;
                        }
                        return false;

                    case UrlType.data:
                        if (a.EndDateTime < DateTime.Now)
                        {
                            db.UrlClasses.Remove(a);
                            db.SaveChanges();
                            return true;
                        }
                        return false;
                }
            }

            return true;
        }
    }
}